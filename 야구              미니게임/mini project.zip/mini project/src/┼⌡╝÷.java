
import java.util.Scanner;

public class ���� {

	public static void main(String[] args) {
	
//	Scanner sc = new Scanner(System.in);
//	Random rc = new Random();
//	int[][]pitcher = new int[5][5];
//	int[]ball = new int [5];
//	int pitcherNum = 0;
//	
//	
//	for (int i = 0; i < pitcher.length; i++) {
//		for (int j = 0; j < 5; j++) {
//			pitcher[i][j] = ++pitcherNum;
//		
//			
//		System.out.print(pitcher[i][j]+"\t");
//		}
//	System.out.println();
//	}
//	System.out.println(" ");
//	
//	
//	
//	int[][]com = new int[5][5];
//	int comNum = 0;
//	
//	
//	for (int i = 0; i < com.length; i++) {
//		for (int j = 0; j < 5; j++) {
//			com[i][j] = ++comNum;
//		
//			
//		System.out.print(com[i][j]+"\t");
//		}
//	System.out.println();
//	}
//	
//	int bet = rc.nextInt(5);
//	int bet2 = rc.nextInt(5);
//		
//	
//	System.out.println(com[bet][bet2]);
//	
//
//	
//	int strike = 0;
//	int ��Ÿ = 0;
//	while (strike<9) {
//		System.out.print("���� �����ðڽ��ϱ�? ");
//		int b = sc.nextInt();
//		 bet = rc.nextInt(5);
//		 bet2 = rc.nextInt(5);
//		for (int i = 1; i >=0; i--) {
//			if(b>0) {
//				ball[i]=b%10;
//				b/=10;
//			}}
//			System.out.println(pitcher[ball[0]][ball[1]]);
//			System.out.println(com[bet][bet2]);
//	if(pitcher[ball[0]][ball[1]]!=com[bet][bet2]) {
//		++strike;
//		System.out.println("��Ʈ����ũ");
//		System.out.println(strike);
//	}else  {
//		++��Ÿ;
//		System.out.println("��Ÿ�Դϴ�");
//		if(��Ÿ>4) {
//			System.out.println("���� ��ü ���ϳ׿�");
//			
//		}
//		
//		
//	}else if(pitcher[ball[0]][ball[1]]==com[bet][bet2]) {
//		System.out.println("Ȩ��~~ ���� ��ü ���ϳ׿�");
//		break;
//	}	
//	}
//		
	}
	}
	

