package com.example.springweb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownImageActivity extends AppCompatActivity {
    ImageView img1;
    Button btnLoad;
    String imgUrl=Common.SERVER_URL+"/mobile/images/lemon.jpg";
    Bitmap bm;
    Handler handler=new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            //이미지뷰에 비트맵 이미지 출력
            img1.setImageBitmap(bm);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_down_image);

        btnLoad=findViewById(R.id.btnLoad);
        img1=findViewById(R.id.img1);
        btnLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                downImg(imgUrl);
            }
        });
    }
    void downImg(final String file){
        Thread th=new Thread(new Runnable() {
            @Override
            public void run() {
                URL url=null;
                try{
                    url=new URL(file);
                    HttpURLConnection conn=(HttpURLConnection)url.openConnection();
                    conn.connect();
                    //스트림 생성
                    InputStream is=conn.getInputStream();
                    // 이미지를 비트맵으로 읽어옴
                    bm= BitmapFactory.decodeStream(is);
                    //핸들러에게 화면 처리 요청
                    handler.sendEmptyMessage(0);
                    conn.disconnect();
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        th.start();
    }
}