package com.example.springweb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class BookListJsonActivity extends AppCompatActivity {

    ArrayList<BookDTO> items;
    RecyclerView rv;
    RecyclerView.Adapter myAdapter;

    Handler handler=new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            Log.i("test","size:"+items.size());
            myAdapter = new MyAdapter();
            rv.setAdapter(myAdapter);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_list);

        rv = findViewById(R.id.rv);
        rv.setLayoutManager(new LinearLayoutManager(this,
                RecyclerView.VERTICAL, false));
        rv.addItemDecoration(new DividerItemDecoration(rv.getContext(),
                DividerItemDecoration.VERTICAL));


        final StringBuilder sb=new StringBuilder();
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    items = new ArrayList<>();
//                    String page = Common.SERVER_URL
//                            + "/mobile/book_list_json.do";
                    String page=
                            "http://192.168.189.128/mobile/json.php";
                    Log.i("test","url:"+page);
                    URL url = new URL(page);
                    HttpURLConnection conn =
                            (HttpURLConnection) url.openConnection();
                    if(conn!=null){
                        conn.setConnectTimeout(10000);
                        conn.setUseCaches(false);
                        //정상적으로 접속된 경우
                        if(conn.getResponseCode()==
                                HttpURLConnection.HTTP_OK){
                            //입력스트림 생성
                            BufferedReader br
                                =new BufferedReader(
new InputStreamReader(conn.getInputStream(),"utf-8"));
                            while(true){
                                //한 라인을 읽음
                                String line=br.readLine();
                                //더 이상 내용이 없으면 반복문 종료
                                if(line==null) break;
                                //스트링빌더에 추가
                                sb.append(line+"\n");
                            }
                            br.close();
                        }
                        conn.disconnect();
                    }
                    //string=>json
                    JSONObject jsonObj=new JSONObject(sb.toString());
                    //웹서버에서 전달한 json array
                    JSONArray jArray=(JSONArray)jsonObj.get("sendData");
                    for(int i=0; i<jArray.length(); i++){
                        //i번째 json object
                        JSONObject row=jArray.getJSONObject(i);
                        // dto에 저장
                        BookDTO dto=new BookDTO();
                        dto.setAmount(row.getInt("amount"));
                        dto.setBook_code(row.getInt("book_code"));
                        dto.setBook_name(row.getString("book_name"));
                        dto.setPress(row.getString("press"));
                        dto.setPrice(row.getInt("price"));
                        //리스트에 추가
                        items.add(dto);
                    }
                    handler.sendEmptyMessage(0);
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        th.start();
    }

    //내부 클래스(커스텀 아답터)
    class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent,
                    int viewType) {
            View rowItem = LayoutInflater.from(parent.getContext()).inflate(
                    R.layout.book_row, parent, false);
            return new ViewHolder(rowItem);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder,
                                     int position) {
            holder.txtBookName.setText(items.get(position).getBook_name());
            holder.txtPress.setText(items.get(position).getPress());
        }

        @Override
        public int getItemCount() {
            Log.i("test", "자료개수:" + items.size() + "");
            return items.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder
                implements View.OnClickListener {
            private TextView txtBookName, txtPress;

            public ViewHolder(View view) {
                super(view);
                view.setOnClickListener(this);
                this.txtBookName = view.findViewById(R.id.book_name);
                this.txtPress = view.findViewById(R.id.press);
            }

            @Override
            public void onClick(View view) {

            }
        }
    }
}






