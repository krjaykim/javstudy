package com.example.springweb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    EditText editId, editPwd;
    Button btnLogin;
    TextView txtResult;
    WebView webview1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editId=findViewById(R.id.editId);
        editPwd=findViewById(R.id.editPwd);
        txtResult=findViewById(R.id.txtResult);
        btnLogin=findViewById(R.id.btnLogin);
        webview1=findViewById(R.id.webview1);
        //웹뷰에서 자바스크립트 실행 허용
        webview1.getSettings().setJavaScriptEnabled(true);
        // url에 접속
        webview1.loadUrl("http://192.168.10.5:9000/mobile/login.do");
        // 안드로이드와 웹서버의 통신을 위한 브릿지 클래스
        webview1.addJavascriptInterface(new AndroidBridge(), "android");
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id=editId.getText().toString();
                String pwd=editPwd.getText().toString();
                //웹서버의 자바스크립트 호출
                webview1.loadUrl("javascript:login('"+id+"','"+pwd+"')");
            }
        });
    }
    Handler handler=new Handler();
    class AndroidBridge{
        @JavascriptInterface
        public void setMessage(final String arg){
            handler.post(new Runnable() {
                @Override
                public void run() {
                    //웹서버의 실행 결과값을 텍스트뷰에 출력
                    txtResult.setText(arg.trim());
                }
            });
        }
    }

}