package com.example.springweb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BrowserDemo4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser_demo4);
    }
}