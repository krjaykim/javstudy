package com.example.springweb;

public class Common {
    public static String SERVER_URL="http://192.168.10.5:9000";
}
